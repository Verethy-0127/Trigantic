After your purchase, you'll see a 'View your files' link in your account where you can download the files for the clipart you have purchased. You will also receive an email with a link to the download files as well.

Included with this purchase:
-One or more downloadable zip files for the clipart purchased with one file for each design in the set, all watermark-free, in the following formats:
      o	PDF file
      o	SVG file
      o	PNG file
      o	JPG file
      o	DXF file
      o	EPS file

-You are purchasing a single commercial license from Sniggle Sloth as outlined below.

-----------------------------------------------------------
<< What you CAN do with this license >>

-You may use these images for your personal or commercial projects and some finished products that you sell. 

<< What you CAN'T do with this license >>

-You may not sell or distribute our designs and files as-is, or use to make other digital products. For example, reselling our designs as digital content or using our designs to make your own clipart for resale is not permitted.

-The artwork may not be used in any manner related to the sale of rubber stamps.

-The artwork may not be used in any manner related to the sale of books.

-The artwork may not be used in a manner that can be deemed as offensive.

-If any of these points are unclear in relation to your intended use, please contact us before buying.

<< Additional license requirements >>

For commercial projects, attribution must be included wherever the artwork is visible. For example, if you are using the image as part of a t-shirt for sale on Etsy, artwork attribution must be included on the Etsy listing and on the product packaging.

Artwork attribution should read: 

The artwork used is licensed from Sniggle Sloth. 
-----------------------------------------------------------

Please do not ask for any artwork customizations or changes, as we are currently unable to accept these requests, and can only sell the product as it is currently listed.

Due to the nature of this product, we are unable to accept returns, exchanges or cancellations. 

�Sniggle Sloth
